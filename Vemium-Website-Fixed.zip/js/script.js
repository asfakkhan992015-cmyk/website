document.addEventListener("DOMContentLoaded", () => {

    const header = document.getElementById("header");
    const menuBtn = document.getElementById("menuBtn");
    const mobileMenu = document.getElementById("mobileMenu");
    const backTop = document.getElementById("backTop");
    const shareBtn = document.getElementById("shareBtn");
    const contactForm = document.getElementById("contactForm");
    const formMessage = document.getElementById("formMessage");
    const submitBtn = document.getElementById("submitBtn");

    /* HEADER SHADOW */
    const handleScroll = () => {
        header.classList.toggle("scrolled", window.scrollY > 40);
        backTop.classList.toggle("show", window.scrollY > 500);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();

    /* MOBILE MENU - FIXED */
    const closeMenu = () => {
        mobileMenu.classList.remove("active");
        mobileMenu.setAttribute("aria-hidden", "true");
        menuBtn.setAttribute("aria-expanded", "false");
        menuBtn.setAttribute("aria-label", "Open menu");
        menuBtn.innerHTML = '<i class="fa-solid fa-bars"></i>';
        document.body.classList.remove("menu-open");
    };

    const openMenu = () => {
        mobileMenu.classList.add("active");
        mobileMenu.setAttribute("aria-hidden", "false");
        menuBtn.setAttribute("aria-expanded", "true");
        menuBtn.setAttribute("aria-label", "Close menu");
        menuBtn.innerHTML = '<i class="fa-solid fa-xmark"></i>';
        document.body.classList.add("menu-open");
    };

    menuBtn.addEventListener("click", () => {
        mobileMenu.classList.contains("active") ? closeMenu() : openMenu();
    });

    mobileMenu.querySelectorAll("a").forEach(link => {
        link.addEventListener("click", closeMenu);
    });

    window.addEventListener("resize", () => {
        if (window.innerWidth > 900) closeMenu();
    });

    /* ACTIVE NAV */
    const navLinks = document.querySelectorAll(".navbar a");
    const sections = document.querySelectorAll("section[id]");

    const updateActiveNav = () => {
        let current = "home";

        sections.forEach(section => {
            const top = section.offsetTop - 180;
            if (window.scrollY >= top) current = section.id;
        });

        navLinks.forEach(link => {
            link.classList.toggle(
                "active",
                link.getAttribute("href") === "#" + current
            );
        });
    };

    window.addEventListener("scroll", updateActiveNav, { passive: true });
    updateActiveNav();

    /* BACK TO TOP */
    backTop.addEventListener("click", () => {
        window.scrollTo({ top: 0, behavior: "smooth" });
    });

    /* SHARE WEBSITE */
    shareBtn.addEventListener("click", async () => {
        const shareData = {
            title: "Vemium | Premium Interior Design",
            text: "Check out Vemium Interior Design.",
            url: window.location.href
        };

        try {
            if (navigator.share) {
                await navigator.share(shareData);
            } else if (navigator.clipboard) {
                await navigator.clipboard.writeText(window.location.href);
                showMessage("Website link copied. You can share it anywhere.");
            } else {
                prompt("Copy this website link:", window.location.href);
            }
        } catch (error) {
            /* User cancelled share - do nothing */
        }
    });

    function showMessage(message) {
        formMessage.textContent = message;
        setTimeout(() => {
            formMessage.textContent = "";
        }, 5000);
    }

    /* CONTACT FORM -> FORMSPREE EMAIL */
    contactForm.addEventListener("submit", async (event) => {
        event.preventDefault();

        const action = contactForm.getAttribute("action");

        if (!action || action.includes("YOUR_FORMSPREE_ID")) {
            formMessage.textContent =
                "First add your Formspree ID in index.html.";
            return;
        }

        submitBtn.disabled = true;
        submitBtn.innerHTML =
            'Sending... <i class="fa-solid fa-spinner fa-spin"></i>';

        try {
            const response = await fetch(action, {
                method: "POST",
                body: new FormData(contactForm),
                headers: { "Accept": "application/json" }
            });

            if (response.ok) {
                formMessage.textContent =
                    "Thank you! Your enquiry has been sent successfully.";
                contactForm.reset();
            } else {
                formMessage.textContent =
                    "Something went wrong. Please try again.";
            }
        } catch (error) {
            formMessage.textContent =
                "Please check your internet connection and try again.";
        } finally {
            submitBtn.disabled = false;
            submitBtn.innerHTML =
                'Send Enquiry <i class="fa-solid fa-arrow-right"></i>';
        }
    });

    /* CURRENT YEAR */
    document.getElementById("year").textContent = new Date().getFullYear();
});
