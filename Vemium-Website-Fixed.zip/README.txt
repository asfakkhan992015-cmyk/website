VEMIUM WEBSITE - SETUP

1. Put your images in the same folder as index.html:
   logo.jpeg
   me.jpeg
   project-1.jpg
   project-2.jpg
   project-3.jpg
   project-4.jpg
   project-5.jpg
   project-6.jpg

2. IMPORTANT:
   The original code was using images from the same folder as index.html,
   so this version keeps that setup.

3. Replace these placeholders in index.html:
   +91 XXXXX XXXXX
   YOUR_EMAIL@gmail.com
   YOUR OFFICE ADDRESS HERE
   YOUR_INSTAGRAM_LINK
   YOUR_FACEBOOK_LINK
   YOUR_YOUTUBE_LINK
   91XXXXXXXXXX

4. FORM EMAIL:
   This static website uses Formspree.
   - Create an account on Formspree.
   - Create a new form.
   - Set the email where enquiries should arrive.
   - Copy the Formspree endpoint ID.
   - Replace:
       https://formspree.io/f/YOUR_FORMSPREE_ID
     with your real endpoint.

   Example:
       https://formspree.io/f/abcdwxyz

5. WEBSITE SHARE:
   The Share button uses the phone/browser Share feature where supported.
   If Share is not supported, it copies the website URL.

6. MOBILE MENU:
   The menu now opens/closes correctly on phone and closes after selecting a page.
